# HiveLoop Claude Code Skill

Automate HiveBoard integration in any Python agentic application with one Claude Code command.

## Quick Start

1. Copy the contents of this folder into your project:

```
cp -r . your-project/.claude/commands/
```

2. Open Claude Code in your project directory and run:

```
/integrate-hiveloop hb_live_your_api_key
```

3. Start your agent and open [hiveboard.net](https://hiveboard.net) to see live telemetry.

## What's Inside

| File | Purpose |
|---|---|
| `integrate-hiveloop.md` | Main skill — guides the 5-phase integration |
| `sdk-quick-reference.md` | All 28 sensor function signatures for lookup |
| `examples/before-after.py` | Complete before/after code example |

## What It Does

- **Phase 1** — Scans your codebase (framework, entry point, tools, LLM calls)
- **Phase 2** — Adds `hiveloop` dependency
- **Phase 3** — Minimum viable instrumentation (init, agent, task, llm_call, shutdown)
- **Phase 4** — Enhanced sensors (action tracking, plans, issues, approvals, logging, heartbeat)
- **Phase 5** — Verification checklist

## Supported Frameworks

LangChain · CrewAI · AutoGen · Semantic Kernel · Custom agent loops

## Need an API Key?

Register at [hiveboard.net](https://hiveboard.net) → API Keys panel → Copy or create a key.

## Full Documentation

See [hiveboard.net/docs/claude-code-skill.html](https://hiveboard.net/docs/claude-code-skill.html)
