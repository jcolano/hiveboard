"""
HiveLoop Integration — Before & After Example

Shows a simple sales-lead processing agent before and after
HiveLoop instrumentation. Use this as a concrete reference
when integrating into real agentic applications.
"""

# ═══════════════════════════════════════════════════════════
# BEFORE — No observability
# ═══════════════════════════════════════════════════════════

import openai
import logging

logger = logging.getLogger(__name__)
client = openai.OpenAI()


def enrich_lead(lead: dict) -> dict:
    """Look up company info from CRM."""
    # ... CRM API call ...
    return {"company": "Acme Corp", "revenue": "10M"}


def score_lead(lead: dict, enrichment: dict) -> str:
    """Use LLM to score the lead."""
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "Score this sales lead 1-10."},
            {"role": "user", "content": f"Lead: {lead}, Company: {enrichment}"},
        ],
    )
    return response.choices[0].message.content


def process_leads(leads: list[dict]):
    """Main processing loop."""
    for lead in leads:
        try:
            enrichment = enrich_lead(lead)
            score = score_lead(lead, enrichment)
            print(f"Lead {lead['id']}: score={score}")
        except Exception as e:
            logger.error(f"Failed to process lead {lead['id']}: {e}")


if __name__ == "__main__":
    leads = [
        {"id": "lead-1", "name": "Jane", "email": "jane@acme.com"},
        {"id": "lead-2", "name": "Bob", "email": "bob@initech.com"},
    ]
    process_leads(leads)


# ═══════════════════════════════════════════════════════════
# AFTER — Full HiveLoop instrumentation
# ═══════════════════════════════════════════════════════════

import time
import atexit
import openai
import logging
import hiveloop                                          # NEW
from hiveloop import tool_payload                        # NEW
from hiveloop.contrib.log_handler import HiveBoardLogHandler  # NEW

logger = logging.getLogger(__name__)
client = openai.OpenAI()

# ── 1. SDK Init (entry point) ──
hb = hiveloop.init(                                      # NEW
    api_key="hb_live_abc123...",
    environment="production",
)

# ── 2. Agent Registration ──
agent = hb.agent(                                        # NEW
    "sales-scorer",
    type="sales",
    framework="custom",
    version="1.0.0",
    heartbeat_payload=lambda: {                          # NEW — custom state
        "leads_in_memory": len(getattr(agent, '_leads', [])),
    },
)

# ── Log bridge (catch-all for warnings/errors) ──
logging.getLogger().addHandler(HiveBoardLogHandler(agent))  # NEW


# ── 4.1 Action tracking (tool functions) ──
@agent.track("enrich_lead")                              # NEW — decorator
def enrich_lead(lead: dict) -> dict:
    """Look up company info from CRM."""
    # ... CRM API call ...
    return {"company": "Acme Corp", "revenue": "10M"}


def score_lead(task, lead: dict, enrichment: dict) -> str:
    """Use LLM to score the lead."""
    t0 = time.time()                                     # NEW — timing
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "Score this sales lead 1-10."},
            {"role": "user", "content": f"Lead: {lead}, Company: {enrichment}"},
        ],
    )
    elapsed = int((time.time() - t0) * 1000)

    # ── 3.4 LLM call tracking ──
    task.llm_call(                                       # NEW
        name="score_lead",
        model="gpt-4o",
        tokens_in=response.usage.prompt_tokens,
        tokens_out=response.usage.completion_tokens,
        cost=None,  # calculate if you have pricing
        duration_ms=elapsed,
    )
    return response.choices[0].message.content


def process_leads(leads: list[dict]):
    """Main processing loop — each lead is a task."""
    for lead in leads:
        # ── 3. Task wrapping ──
        with agent.task(                                 # NEW — context manager
            lead["id"],
            project="sales-pipeline",
            type="lead_scoring",
        ) as task:
            try:
                enrichment = enrich_lead(lead)
                score = score_lead(task, lead, enrichment)
                task.set_payload({                       # NEW — result data
                    "score": score,
                    "company": enrichment.get("company"),
                })
                print(f"Lead {lead['id']}: score={score}")
            except Exception as e:
                # ── Issue reporting ──
                agent.report_issue(                      # NEW
                    f"Failed to process lead {lead['id']}: {e}",
                    severity="high",
                    category="data_quality",
                )
                raise  # task context manager auto-emits task_failed


if __name__ == "__main__":
    leads = [
        {"id": "lead-1", "name": "Jane", "email": "jane@acme.com"},
        {"id": "lead-2", "name": "Bob", "email": "bob@initech.com"},
    ]
    process_leads(leads)

    # ── 5. Shutdown ──
    hiveloop.shutdown()                                  # NEW
